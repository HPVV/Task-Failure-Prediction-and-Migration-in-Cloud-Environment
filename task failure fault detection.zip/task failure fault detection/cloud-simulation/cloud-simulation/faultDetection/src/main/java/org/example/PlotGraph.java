package org.example;

import org.cloudbus.cloudsim.Cloudlet;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PlotGraph {
    public  void plotResults(List<Cloudlet> resultList, String title) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (Cloudlet cloudlet : resultList) {
            if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
                dataset.addValue(cloudlet.getActualCPUTime(), "Execution Time", "Cloudlet " + cloudlet.getCloudletId());
            }
        }

        JFreeChart chart = ChartFactory.createBarChart(
                title,
                "Cloudlet ID",
                "Execution Time",
                dataset,
                PlotOrientation.VERTICAL,
                true,true,false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 600));

        JFrame frame = new JFrame("CloudSim Results");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(chartPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
