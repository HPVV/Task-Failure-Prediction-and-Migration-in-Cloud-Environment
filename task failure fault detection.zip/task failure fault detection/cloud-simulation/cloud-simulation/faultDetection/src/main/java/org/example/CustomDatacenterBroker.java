package org.example;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.SimEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class CustomDatacenterBroker extends DatacenterBroker {

    private Map<Integer, Vm> vmMap = new HashMap<>();
    private List<Cloudlet> receivedCloudlets = new ArrayList<>();
    public CustomDatacenterBroker(String name) throws Exception {
        super(name);
    }

    public void addVm(Vm vm) {
        super.submitVmList(List.of(vm)); // Use submitVmList to submit a single VM
        vmMap.put(vm.getId(), vm);
    }

    public Vm getVmWithId(int vmId) {
        return vmMap.get(vmId);
    }

    public void updateVm(Vm vm) {
        vmMap.put(vm.getId(), vm);
    }

    // Override submitVmList to store VMs in the map
    @Override
    public void submitVmList(List<? extends Vm> list) {
        super.submitVmList(list);

        for (Vm vm : list) {
            vmMap.put(vm.getId(), vm);
        }
    }
    public void clearReceivedCloudlets() {
        receivedCloudlets.clear();
    }
    @Override
    protected void processCloudletReturn(SimEvent evt) {
        Cloudlet cloudlet = (Cloudlet) evt.getData();
        receivedCloudlets.add(cloudlet);
        super.processCloudletReturn(evt);
    }
    public List<Cloudlet> getReceivedCloudlets() {
        return receivedCloudlets;
    }


}