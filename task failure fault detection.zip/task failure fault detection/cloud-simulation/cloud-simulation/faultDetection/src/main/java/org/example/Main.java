package org.example;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;

public class Main {
    private static JTextArea textArea;
    public static void main(String[] args) {
        Boolean isFailed = false;

        // Find Does Model file already generated
        System.out.println(Paths.get("src/model/trained_bilstm_model.h5"));
        if(Boolean.TRUE.equals(checkFilePresent(Paths.get("src/model/trained_bilstm_model.h5")))){
            try {
                // Initialize CloudSim
                CloudSim.init(1, null, false);
                //createUI();
                // Create a data center
                Datacenter datacenter = createDatacenter();

                // Create a custom broker that extends DatacenterBroker
                CustomDatacenterBroker broker = new CustomDatacenterBroker("CustomBroker");

                // Create virtual machines and cloudlets for load testing
                List<Vm> vms = createVirtualMachines(broker.getId(), 1, 128, 1000, 1);
                Random r=new Random();
                List<Cloudlet> cloudlets = createCloudlets(broker.getId(), 8, (r.nextInt(21)+10)*10);

                // Submit virtual machines and cloudlets to the broker
                for (Vm vm : vms) {
                    System.out.println("Vm ."+ vm);
                    broker.addVm(vm);
                }
                System.out.println("Cloudlet ."+broker.getVmList().toString());

                broker.submitCloudletList(cloudlets);

                // Starts the simulation
                CloudSim.startSimulation();

                // Gets the results
                List<Cloudlet> resultList = broker.getCloudletReceivedList();

                // Print the results after the initial simulation
                System.out.println("Results after initial simulation:");
                printCloudletList(resultList);
                // Check if any cloudlet execution time is greater than 1 hour
                for (Cloudlet cloudlet : resultList) {
                    double submissionTime = cloudlet.getSubmissionTime();
                    double executionStartTime = cloudlet.getExecStartTime();
                    double schedulingDelay = executionStartTime - submissionTime;
                    Runtime rt = Runtime.getRuntime();
                    rt.exec("python3 prediction.py "+ cloudlet.getUtilizationOfCpu(cloudlet.getActualCPUTime()) + " "+cloudlet.getUtilizationOfRam(cloudlet.getActualCPUTime())+" "+cloudlet.getUtilizationOfBw(cloudlet.getActualCPUTime())+" 1 "+schedulingDelay+" "+cloudlet.getFinishTime());
                    if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS && cloudlet.getActualCPUTime() > 1) {
                        isFailed = true;
                        System.out.println("Task Failed Due to Max Execution Time Reached");
                    }
                }

// Re-run simulation if VM capacity was increased


                System.out.println("isFailed:"+isFailed);
                if(isFailed){
                    broker.clearReceivedCloudlets();

                    // Stop the current simulation
                    CloudSim.stopSimulation();
                    CloudSim.init(1, null, false);
                    Datacenter newDatacenter = createDatacenter();

                    // Create a custom broker that extends DatacenterBroker
                    CustomDatacenterBroker newBroker = new CustomDatacenterBroker("CustomBroker_01");
                    // Create virtual machines and cloudlets for load testing
                    System.out.println("VM Upgradation Started");
                    List<Vm> newVms = createVirtualMachines(newBroker.getId(), 1, 128, 1000, 1);
                    List<Cloudlet> newCloudlets = createCloudlets(newBroker.getId(), 8, 100);

                    // Submit virtual machines and cloudlets to the broker
                    for (Vm vm : newVms) {
                        System.out.println("Vm ."+ vm);
                        newBroker.addVm(vm);
                    }
                    System.out.println("Cloudlet ."+newBroker.getVmList().toString());

                    newBroker.submitCloudletList(newCloudlets);

                    // Starts the simulation
                    CloudSim.startSimulation();

                    // Gets the results
                    List<Cloudlet> newResultList = newBroker.getCloudletReceivedList();

                    PlotGraph plotGraph = new PlotGraph();
                    plotGraph.plotResults(newResultList, "Task Success After VM Optimization");
                    System.out.println("VM Upgradation Completed, Task Executed");
                    //printCloudletList(newResultList);
                    printCloudletList(newResultList);
                }

                // Plot the results
                if(isFailed){

                    PlotGraph failedGraph = new PlotGraph();
                    failedGraph.plotResults(resultList, "Task Failure Results");
                }
                else {
                    PlotGraph plotGraph = new PlotGraph();
                    plotGraph.plotResults(resultList, "Task Success for First Time");
                }


                // Stops the simulation
                CloudSim.stopSimulation();

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Model File Not Found");
        }
    }
    public static Boolean checkFilePresent(Path path){
        if (Files.exists(path)) {
            if (Files.isDirectory(path)) {
                System.out.println("It is a directory");
            } else if (Files.isRegularFile(path)) {
                System.out.println("File present");
                return true;
            }
        } else {
            System.out.println("File not found ");
            return false;
        }
        System.out.println("File null ");
        return null;
    }
    private static Datacenter createDatacenter() {
        // Create host list
        List<Host> hostList = new ArrayList<>();

        // Create a host with a single processor and 1GB of RAM
        List<Pe> peList = new ArrayList<>();
        peList.add(new Pe(0, new PeProvisionerSimple(1000))); // Adjust MIPS value as needed
        hostList.add(new Host(
                0,
                new RamProvisionerSimple(1024),
                new BwProvisionerSimple(10000),
                1000000,
                peList,
                new VmSchedulerTimeShared(peList)
        ));

        // Create a data center with characteristics
        String arch = "x86";
        String os = "Linux";
        String vmm = "Xen";
        double time_zone = 5.30;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;
        LinkedList<Storage> storageList = new LinkedList<>();
        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch,
                os,
                vmm,
                hostList,
                time_zone,
                cost,
                costPerMem,
                costPerStorage,
                costPerBw
        );

        // Create a data center with the specified name and characteristics
        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter("Datacenter_0", characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return datacenter;
    }

    private static List<Vm> createVirtualMachines(int brokerId, int numberOfVms, int vmRam, int vmMips, int vmPes) {
        List<Vm> vmList = new ArrayList<>();
        for (int i = 0; i < numberOfVms; i++) {
            Vm vm = new Vm(
                    i,
                    brokerId,
                    vmMips,
                    vmPes,
                    vmRam,
                    10000, // bw
                    10000, // size
                    "Xen",
                    new CloudletSchedulerTimeShared()
            );
            vmList.add(vm);
        }
        return vmList;
    }

    private static List<Cloudlet> createCloudlets(int brokerId, int numberOfCloudlets, int cloudletLength) {
        List<Cloudlet> cloudletList = new ArrayList<>();
        for (int i = 0; i < numberOfCloudlets; i++) {
            Cloudlet cloudlet = new Cloudlet(
                    i,
                    cloudletLength,
                    1, // PEs
                    1000, // fileSize
                    1000, // outputSize
                    new UtilizationModelFull(),
                    new UtilizationModelFull(),
                    new UtilizationModelFull()
            );
            cloudlet.setUserId(brokerId);
            cloudletList.add(cloudlet);
        }
        return cloudletList;
    }

    private static void printCloudletList(List<Cloudlet> cloudletList) {

        System.out.println("Cloudlet ID\tStatus\tData center ID\tVM ID\tCpu Usage\tMemory Usage\tDisk usage\t Scheduling Delay\tExecution Time");
        for (Cloudlet cloudlet : cloudletList) {
            double submissionTime = cloudlet.getSubmissionTime();
            double executionStartTime = cloudlet.getExecStartTime();
            double schedulingDelay = executionStartTime - submissionTime;
            System.out.printf("%-24d%-12d%-16d%-12d%-12.2f%-16.2f%-16.2f%n-%-12f-%-12f",
                    cloudlet.getCloudletId(),
                    cloudlet.getCloudletStatus(),
                    cloudlet.getResourceId(),
                    cloudlet.getVmId(),
                    cloudlet.getUtilizationOfCpu(cloudlet.getActualCPUTime()),
                    cloudlet.getUtilizationOfRam(cloudlet.getActualCPUTime()),
                    cloudlet.getUtilizationOfBw(cloudlet.getActualCPUTime()),
                    schedulingDelay,
                    cloudlet.getFinishTime()
                    );
        }
    }

    private static void createUI() {
        JFrame frame = new JFrame("CloudSim Results");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1366, 768);

        JPanel panel = new JPanel();
        textArea = new JTextArea(20, 40);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        panel.add(scrollPane);

        frame.getContentPane().add(BorderLayout.CENTER, panel);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        frame.getContentPane().add(BorderLayout.SOUTH, closeButton);

        frame.setVisible(true);
    }

    private static void displayResultsInUI(List<Cloudlet> cloudletList) {
        StringBuilder resultText = new StringBuilder("Cloudlet ID\tStatus\tData center ID\tVM ID\tCpu Usage\tMemory Usage\tDisk usage\t Scheduling Delay\n");
        for (Cloudlet cloudlet : cloudletList) {
            double submissionTime = cloudlet.getSubmissionTime();
            double executionStartTime = cloudlet.getExecStartTime();
            double schedulingDelay = executionStartTime - submissionTime;
            resultText.append(String.format("%-24d%-12d%-16d%-12d%-12.2f%-16.2f%-16.2f%n-%-12f",
                    cloudlet.getCloudletId(),
                    cloudlet.getCloudletStatus(),
                    cloudlet.getResourceId(),
                    cloudlet.getVmId(),
                    cloudlet.getUtilizationOfCpu(cloudlet.getActualCPUTime()),
                    cloudlet.getUtilizationOfRam(cloudlet.getActualCPUTime()),
                    cloudlet.getUtilizationOfBw(cloudlet.getActualCPUTime()),
                    schedulingDelay
                    )
            );
        }
        textArea.setText(resultText.toString());
    }
}



